class Comic {
  final String title;
  final String imageUrl;
  final String detailUrl;

  Comic({required this.title, required this.imageUrl, required this.detailUrl});
}
